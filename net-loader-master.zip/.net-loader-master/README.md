# .NET Loader
- Logger
- Runs file using task scheduler
- Strings generator
- Self-deletable
